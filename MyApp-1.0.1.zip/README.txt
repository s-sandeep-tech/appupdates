Sample MyApp update package
Version: 1.0.1

This is only a test package. Replace these files with your real published application files.
